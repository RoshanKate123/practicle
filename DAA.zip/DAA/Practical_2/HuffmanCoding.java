import java.util.HashMap;
import java.util.PriorityQueue;
import java.util.Scanner;

public class HuffmanCoding {

    private static HashMap<Character, String> huffmanCodes = new HashMap<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the string to be compressed: ");
        String input = scanner.nextLine();

        // Create a map to store the frequencies of each character in the input string.
        HashMap<Character, Integer> frequencyMap = new HashMap<>();
        for (char c : input.toCharArray()) {
            frequencyMap.put(c, frequencyMap.getOrDefault(c, 0) + 1);
        }

        // Create a priority queue to store the Huffman nodes.
        PriorityQueue<HuffmanNode> priorityQueue = new PriorityQueue<>((a, b) -> a.freq - b.freq);

        // Create a Huffman node for each character in the frequency map.
        for (Character c : frequencyMap.keySet()) {
            priorityQueue.add(new HuffmanNode(c, frequencyMap.get(c)));
        }

        // Construct the Huffman tree.
        HuffmanNode root = constructHuffmanTree(priorityQueue);

        // Generate the Huffman codes for each character.
        generateHuffmanCodes(root, "");

        // Print the Huffman codes.
        System.out.println("Huffman codes:");
        for (Character c : huffmanCodes.keySet()) {
            System.out.println(c + ": " + huffmanCodes.get(c));
        }

        // Compress the input string using the Huffman codes.
        String compressedString = compress(input);

        // Print the compressed string.
        System.out.println("Compressed string: " + compressedString);
    }

    private static HuffmanNode constructHuffmanTree(PriorityQueue<HuffmanNode> priorityQueue) {
        while (priorityQueue.size() > 1) {
            // Extract the two nodes with the lowest frequencies.
            HuffmanNode left = priorityQueue.poll();
            HuffmanNode right = priorityQueue.poll();

            // Create a new internal node with a frequency equal to the sum of the two nodes' frequencies.
            HuffmanNode newNode = new HuffmanNode('\0', left.freq + right.freq);
            newNode.left = left;
            newNode.right = right;

            // Add the new node back to the priority queue.
            priorityQueue.add(newNode);
        }

        // The root of the Huffman tree is the only node left in the priority queue.
        return priorityQueue.poll();
    }

    private static void generateHuffmanCodes(HuffmanNode node, String code) {
        if (node == null) {
            return;
        }

        if (node.left == null && node.right == null) {
            huffmanCodes.put(node.data, code);
            return;
        }

        generateHuffmanCodes(node.left, code + "0");
        generateHuffmanCodes(node.right, code + "1");
    }

    private static String compress(String input) {
        StringBuilder compressedString = new StringBuilder();
        for (char c : input.toCharArray()) {
            compressedString.append(huffmanCodes.get(c));
        }
        return compressedString.toString();
    }

    private static class HuffmanNode {
        char data;
        int freq;
        HuffmanNode left;
        HuffmanNode right;

        HuffmanNode(char data, int freq) {
            this.data = data;
            this.freq = freq;
            this.left = null;
            this.right = null;
        }
    }
}
