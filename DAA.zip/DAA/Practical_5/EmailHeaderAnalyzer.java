import java.util.Scanner;

public class EmailHeaderAnalyzer {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt the user for the email header
        System.out.print("Enter the email header: ");
        String emailHeader = scanner.nextLine();

        // Parse the email header
        EmailHeaderParser parser = new EmailHeaderParser();
        parser.parse(emailHeader);

        // Display the parsed information
        System.out.println("From: " + parser.getFrom());
        System.out.println("To: " + parser.getTo());
        System.out.println("Subject: " + parser.getSubject());
        System.out.println("Date: " + parser.getDate());
        System.out.println("IP Address: " + parser.getIpAddress());
    }
}

class EmailHeaderParser {
    private String from;
    private String to;
    private String subject;
    private String date;
    private String ipAddress;

    public void parse(String emailHeader) {
        // You would need a more sophisticated parsing logic based on the actual email header format.
        // This is a simple example and may not cover all cases.
        // In a real-world scenario, you would use a library or more comprehensive parsing logic.

        // Assume a simple format for demonstration purposes:
        // From: email@example.com
        // To: recipient@example.com
        // Subject: Example Subject
        // Date: Mon, 04 Oct 2021 15:30:00 +0000
        // IP Address: 192.168.1.1

        String[] lines = emailHeader.split("\n");
        for (String line : lines) {
            if (line.startsWith("From:")) {
                this.from = line.substring(6).trim();
            } else if (line.startsWith("To:")) {
                this.to = line.substring(4).trim();
            } else if (line.startsWith("Subject:")) {
                this.subject = line.substring(8).trim();
            } else if (line.startsWith("Date:")) {
                this.date = line.substring(6).trim();
            } else if (line.startsWith("IP Address:")) {
                this.ipAddress = line.substring(11).trim();
            }
        }
    }

    public String getFrom() {
        return from;
    }

    public String getTo() {
        return to;
    }

    public String getSubject() {
        return subject;
    }

    public String getDate() {
        return date;
    }

    public String getIpAddress() {
        return ipAddress;
    }
}
